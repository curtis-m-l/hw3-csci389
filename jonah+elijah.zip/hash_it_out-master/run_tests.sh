export LD_LIBRARY_PATH="."
./test_cache
./test_evictor

