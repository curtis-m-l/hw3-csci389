# HW2: Hash it Out

By Aaron G. (@azggit) and Alex W. (@InternetUnexplorer)

To build everything and run the tests, run `make` in this directory.

## Testing

We decided to use [doctest][1] for our tests, as it seemed relatively simple
while providing more functionality than `assert(...)`.

## Cache Design

Our implementation uses [`std::unordered_map`][2], as it allows for a custom
hash function and maximum load factor while taking care of collision
resolution and dynamic resizing. Things like collision resolution and
resizing can be tricky to get right (especially when performance is
important) and so it seemed best to defer to the standard library's
implementation here.

## FifoEvictor

To prevent the evictor from adding duplicate entries to the FIFO queue when
keys are touched multiple times, our implementation uses
[`std::unordered_set`][3] to keep track of which keys are already in the
queue. The result is that touches and evictions still occur in constant time,
but the eviction queue does not grow arbitrarily large in situations with a
high ratio of touches to evictions.

## LruEvictor

Our implementation uses a [`std::unordered_map`][2] where the values are
iterators to the corresponding entries in the queue. This allows for entries
to be removed from anywhere in the queue in constant time, which is necessary
when touching keys.

[1]: https://github.com/onqtam/doctest
[2]: https://en.cppreference.com/w/cpp/container/unordered_map
[3]: https://en.cppreference.com/w/cpp/container/unordered_set
